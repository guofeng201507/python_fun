from flask import Flask
import os

app = Flask(__name__)

print(os.getenv('FLASK_ENV'))
print(os.getenv('FLASK_APP'))
print(os.getenv('S3_BUCKET'))
print(os.getenv('SECRET_KEY'))


@app.route('/')
def hello_world():
    return 'Hello World!'


if __name__ == '__main__':
    app.run()
